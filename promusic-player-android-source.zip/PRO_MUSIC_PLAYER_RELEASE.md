# ProMusic Player release notes

## App identity and Android compatibility

- Application ID: `com.mycoolmusic.professionalplayer`. Check its availability in Play Console before creating the listing. This package ID creates a new Play app; it cannot update the original Retro Music listing.
- The app module already compiles and targets API 36. Google Play's current requirement for new apps and updates is API 36 or higher.
- The Kotlin package/Gradle `namespace` remains `code.name.monkey.retromusic` so existing source references and generated resources continue to work. The install identity is the separate `applicationId`.

## Local music and bundled media

The library is populated from Android's on-device MediaStore. The app bundle contains no demo audio tracks. The upstream contributor portraits and commercial album-art examples have been removed from the app's runtime assets; player-layout thumbnails now use synthetic ProMusic visuals. The artist/contributor credits and GPL notices remain.

The existing optional lyrics, metadata, artwork, and Cast features can use the network. The network permission does not turn the library scanner into a streaming/catalog scanner. Review the final permission prompts, privacy policy, and Play Console Data safety answers against the features you choose to keep.

## License and store assets

This project is based on RetroMusicPlayer, whose source is licensed under GPL-3.0. `LICENSE.md` and upstream copyright notices are retained. Before distributing a modified build, follow the license terms for modified versions and source availability, clearly identify your changes, and verify that you have rights to the name, icon, screenshots, and other listing materials you publish.

The launcher icon and Play Store icon are rebranded. The upstream phone screenshots have been removed from Fastlane metadata; capture new screenshots from your own final build before submitting the store listing.

The app still contains upstream support, website, and social links where no replacement contact details were provided. Replace or remove those destinations before publishing so users are not sent to the original project by mistake.

## Create a signed Play bundle

Use JDK 21 and Android SDK 36. From the `android/` directory, generate a private upload key locally:

```sh
keytool -genkeypair -v -storetype PKCS12 \
  -keystore app/promusic-upload-key.p12 \
  -alias promusicplayer -keyalg RSA -keysize 2048 -validity 10000
```

Create `android/retro.properties` locally (it is ignored by Git) with:

```properties
storeFile=promusic-upload-key.p12
storePassword=YOUR_LOCAL_STORE_PASSWORD
keyAlias=promusicplayer
keyPassword=YOUR_LOCAL_KEY_PASSWORD
```

Keep the key and passwords private and make a secure backup. Do not commit them or send them in chat. The release build no longer falls back to the debug key; without `retro.properties`, Gradle produces an unsigned release bundle that cannot be uploaded as-is.

Build the Google Play flavor:

```sh
./gradlew :app:bundleNormalRelease
```

The bundle is written to:

```text
app/build/outputs/bundle/normalRelease/app-normal-release.aab
```

Upload it through Play Console and enroll in Play App Signing when prompted. Keep the upload key consistent for later releases.