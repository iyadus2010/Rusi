<div align="center">
  <img src="app/src/main/ic_launcher-web.png" height="128" alt="ProMusic Player icon">
  <h1>ProMusic Player for Android</h1>
</div>

ProMusic Player is a rebranded fork of RetroMusicPlayer. The original GPL-3.0 license and contributor notices are retained; see [the release guide](PRO_MUSIC_PLAYER_RELEASE.md) before distributing builds.

The app scans audio files in the device's local media library and keeps playback, the mini-player, equalizer integration, and synchronized-lyrics views. It does not bundle demo tracks.

**Google Play identity:** `com.mycoolmusic.professionalplayer`  
**Build:** JDK 21 and Android SDK 36; run `./gradlew :app:bundleNormalRelease` from this directory. See [signed bundle instructions](PRO_MUSIC_PLAYER_RELEASE.md).

The gallery images below are synthetic UI previews, not screenshots captured from a shipping build. Capture fresh device screenshots for the Play listing.

## 📱 Preview gallery
### Now-playing preview styles
| <img src="screenshots/adaptive.jpg" width="200"/> | <img src="screenshots/blur.jpg" width="200"/> | <img src="screenshots/classic.jpg" width="200"/> |
|:---:|:---:|:---:|
|Adaptive preview| Blur preview | Classic preview |

### Player and queue previews
| <img src="screenshots/normal.jpg" width="200"/>| <img src="screenshots/playlists.jpg" width="200"/>| <img src="screenshots/material.jpg" width="200"/>| <img src="screenshots/peek.jpg" width="200"/>| <img src="screenshots/tiny.jpg" width="200"/>|
|:---:|:---:|:---:|:---:|:---:|
| Player | Local tracks | Player style | Queue | Compact player |

### Synced lyrics screen (Over Cover)
| <img src="screenshots/synced_over_light.jpg" width="200"/>| <img src="screenshots/synced_over_dark.jpg" width="200"/>| <img src="screenshots/synced_over_black.jpg" width="200"/>|
|:---:|:---:|:---:|
| Synced Over Cover light | Synced Over Cover dark | Synced Over Cover black |

### Synced lyrics screen (Replace Cover)
| <img src="screenshots/synced_replace_light.jpg" width="200"/>| <img src="screenshots/synced_replace_dark.jpg" width="200"/>| <img src="screenshots/synced_replace_black.jpg" width="200"/>|
|:---:|:---:|:---:|
| Synced Replace Cover light | Synced Replace Cover dark | Synced Replace Cover black |

### 10+ Now playing themes
| <img src="screenshots/normal.jpg" width="200"/>	|<img src="screenshots/fit.jpg" width="200"/>|   <img src="screenshots/flat.jpg" width="200"/>  	|    <img src="screenshots/color.jpg" width="200"/> 	|     <img src="screenshots/material.jpg" width="200"/>	|
|:-----:	|:-----:	|:-----:	|:-----:	|:-----:	|
| Normal 	| Fit 	| Flat 	| Color 	| Material 	|

| <img src="screenshots/classic.jpg" width="200"/>	|<img src="screenshots/adaptive.jpg" width="200"/>|   <img src="screenshots/blur.jpg" width="200"/>  	|    <img src="screenshots/tiny.jpg" width="200"/> 	|     <img src="screenshots/peek.jpg" width="200"/>	|
|:-----:	|:-----:	|:-----:	|:-----:	|:-----:	|
| Classic 	| Adaptive 	| Blur 	| Tiny 	| Peek 	|

___

## 🧭 Navigation never been made easier 
Self-explanatory interface without overloaded menus.

## 🎨 Colorful
The first-install theme uses a deep charcoal surface with cyan and violet
accents. Light and black display themes remain available in settings.

## 🏠 Home
Where you can view your recently/top played artists, albums and
favorite songs.

## 📦 Included Features
-  Base 3 themes (Clearly White, Kinda Dark and Just Black)
-  Chromecast support
-  Choose from 10+ now playing themes
-  Driving Mode
-  Headset/Bluetooth support
-  Music duration filter
-  Android Auto support
-  Wallpaper accent picker on Android 8.1+
-  Material You support on Android 12+
-  Monet themed icon support on Android 13+
-  Folder support - Play songs by folder
-  Gapless playback
-  Volume controls
-  Carousel effect for album covers
-  Home screen widgets
-  Lock screen playback controls
-  Lyrics screen (download and sync with music)
-  Sleep timer
-  Easy drag to sort playlist & play queue
-  Tag editor
-  Create, edit and import playlists
-  Playing queue with reorder
-  User profile
-  30+ languages support (help translate the project: [Crowdin](https://crowdin.com/project/retromusicplayer)
-  Browse and play your music by songs, albums, artists, playlists and
  genre
-  Smart Auto Playlists - Recently played, most played and history
-  Build your playlist on the go

We are trying our best to bring you the best user experience. The app is regularly updated for bug fixes and new features.

___


## Support and translations

This fork does not yet have dedicated support channels. The app still contains
some support and website links inherited from its upstream project; replace
those destinations before publishing. Translation credits and existing
translations originate from [the upstream Crowdin project](https://crowdin.com/project/retromusicplayer).

## 🗂️ License

ProMusic Player is based on Retro Music Player and is distributed under the
GNU General Public License v3.0 (GPLv3), available [here](LICENSE.md).


>Please note: Retro Music Player is a local music player app. It
>doesn't support music downloading or online music streaming.
