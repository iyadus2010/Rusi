#!/usr/bin/env python3
"""Regenerate ProMusic launcher, store, and safe player-preview artwork."""

from pathlib import Path
import subprocess
import tempfile


ROOT = Path(__file__).resolve().parent.parent
ANDROID = ROOT / "app" / "src" / "main"
PREVIEW_NAMES = (
    "np_adaptive",
    "np_blur_card",
    "np_blur",
    "np_card",
    "np_circle",
    "np_classic",
    "np_color",
    "np_fit",
    "np_flat",
    "np_full",
    "np_gradient",
    "np_material",
    "np_minimalistic_circle",
    "np_normal",
    "np_peek",
    "np_plain",
    "np_simple",
    "np_tiny",
)
ACCENTS = ("#54DDF5", "#A88BFA", "#78E6D2", "#8C9BFF")
WIDGET_SIZES = {
    "widget_big_info": (636, 386),
    "widget_card_info": (592, 104),
    "widget_classic": (486, 164),
    "widget_small": (462, 156),
    "widget_text": (510, 228),
}
README_PREVIEWS = {
    "adaptive": "np_adaptive",
    "blur": "np_blur",
    "classic": "np_classic",
    "color": "np_color",
    "fit": "np_fit",
    "flat": "np_flat",
    "material": "np_material",
    "normal": "np_normal",
    "peak": "np_card",
    "peek": "np_peek",
    "playlists": "np_peek",
    "tiny": "np_tiny",
}


def convert(source: Path, destination: Path, size: str, quality: str | None = None) -> None:
    command = ["magick", str(source), "-resize", f"{size}!", "-strip"]
    if quality is not None:
        command.extend(["-quality", quality])
    command.append(str(destination))
    subprocess.run(command, check=True)


def preview_svg(name: str, accent: str, index: int) -> str:
    if name == "np_peek":
        body = """
          <text x="92" y="322" fill="#F4F6FF" font-size="46" font-weight="700">UP NEXT</text>
          <text x="92" y="378" fill="#AEB5C8" font-size="25">Music on this device</text>
          <g transform="translate(0 430)">
            <rect x="74" y="0" width="932" height="1280" rx="38" fill="#191D2B"/>
        """
        for row in range(5):
            y = 80 + row * 224
            body += f"""
              <rect x="112" y="{y}" width="144" height="144" rx="24" fill="url(#cover{row % 2})"/>
              <circle cx="184" cy="{y + 72}" r="39" fill="none" stroke="{accent}" stroke-width="5" opacity=".8"/>
              <text x="300" y="{y + 62}" fill="#F1F3FC" font-size="34">Local track {row + 1}</text>
              <text x="300" y="{y + 108}" fill="#AEB5C8" font-size="24">From your library</text>
              <path d="M112 {y + 183}h856" stroke="#34394B" stroke-width="2"/>
            """
        body += """
            <rect x="98" y="1320" width="884" height="118" rx="30" fill="#242A3C"/>
            <circle cx="180" cy="1379" r="32" fill="none" stroke="#54DDF5" stroke-width="5"/>
            <text x="238" y="1374" fill="#F1F3FC" font-size="29">Local track</text>
            <text x="238" y="1410" fill="#AEB5C8" font-size="21">ProMusic Player</text>
            <path d="M865 1360v38m-18-19h36" stroke="#F1F3FC" stroke-width="6" stroke-linecap="round"/>
          </g>
        """
    else:
        art_size = 800
        art_x = 140
        art_y = 250
        radius = 44
        if "circle" in name:
            art_size = 720
            art_x = 180
            art_y = 286
            radius = art_size // 2
        elif name == "np_tiny":
            art_size = 470
            art_x = 305
            art_y = 350
            radius = 30
        elif name in ("np_full", "np_fit", "np_adaptive"):
            art_size = 900
            art_x = 90
            art_y = 205
            radius = 20 if name == "np_full" else 52
        if name in ("np_flat", "np_classic"):
            radius = 8
        clip_shape = (
            f'<circle cx="{art_x + art_size / 2}" cy="{art_y + art_size / 2}" '
            f'r="{art_size / 2}" />'
            if radius == art_size // 2
            else f'<rect x="{art_x}" y="{art_y}" width="{art_size}" height="{art_size}" rx="{radius}" />'
        )
        info_y = art_y + art_size + 112
        body = f"""
          <defs>
            <clipPath id="art-clip">{clip_shape}</clipPath>
          </defs>
          <rect x="{art_x}" y="{art_y}" width="{art_size}" height="{art_size}"
                rx="{radius}" fill="url(#cover{index % 2})" clip-path="url(#art-clip)"/>
          <g clip-path="url(#art-clip)">
            <circle cx="{art_x + art_size * .64}" cy="{art_y + art_size * .38}"
                    r="{art_size * .27}" fill="{accent}" opacity=".2"/>
            <circle cx="{art_x + art_size * .36}" cy="{art_y + art_size * .70}"
                    r="{art_size * .24}" fill="#A88BFA" opacity=".22"/>
            <circle cx="{art_x + art_size * .50}" cy="{art_y + art_size * .50}"
                    r="{art_size * .31}" fill="none" stroke="#E7E9FF" stroke-width="5" opacity=".43"/>
            <circle cx="{art_x + art_size * .50}" cy="{art_y + art_size * .50}"
                    r="{art_size * .21}" fill="none" stroke="{accent}" stroke-width="12" opacity=".82"/>
            <path d="M{art_x + art_size * .18} {art_y + art_size * .57}
                     C{art_x + art_size * .34} {art_y + art_size * .25},
                      {art_x + art_size * .64} {art_y + art_size * .78},
                      {art_x + art_size * .84} {art_y + art_size * .42}"
                  fill="none" stroke="#F4F6FF" stroke-width="8" stroke-linecap="round" opacity=".75"/>
            <text x="{art_x + art_size / 2}" y="{art_y + art_size * .53}"
                  text-anchor="middle" fill="#F4F6FF" font-size="{art_size * .09}"
                  font-weight="700" letter-spacing="7">PRO MUSIC</text>
          </g>
          <text x="540" y="{info_y}" text-anchor="middle" fill="#F4F6FF"
                font-size="42" font-weight="700">Local track</text>
          <text x="540" y="{info_y + 54}" text-anchor="middle" fill="#AEB5C8"
                font-size="27">From your library</text>
          <rect x="125" y="{info_y + 132}" width="830" height="5" rx="3" fill="#454B5E"/>
          <rect x="125" y="{info_y + 132}" width="335" height="5" rx="3" fill="{accent}"/>
          <circle cx="460" cy="{info_y + 134}" r="12" fill="{accent}"/>
          <text x="124" y="{info_y + 182}" fill="#AEB5C8" font-size="20">1:18</text>
          <text x="898" y="{info_y + 182}" fill="#AEB5C8" font-size="20">3:42</text>
          <g fill="none" stroke="#E8EAF4" stroke-width="7" stroke-linecap="round" stroke-linejoin="round">
            <path d="M285 {info_y + 285}l-40 32 40 32M245 {info_y + 317}h66"/>
            <path d="M795 {info_y + 285}l40 32-40 32M835 {info_y + 317}h-66"/>
          </g>
          <circle cx="540" cy="{info_y + 317}" r="55" fill="{accent}"/>
          <path d="M528 {info_y + 286}v62l50-31z" fill="#10131D"/>
          <text x="540" y="2040" text-anchor="middle" fill="#AEB5C8"
                font-size="22" letter-spacing="3">MINI PLAYER  ·  EQUALIZER  ·  LYRICS</text>
        """

    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="2280" viewBox="0 0 1080 2280">
      <defs>
        <linearGradient id="background" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="#171B2A"/>
          <stop offset="1" stop-color="#10131D"/>
        </linearGradient>
        <linearGradient id="cover0" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stop-color="#253454"/>
          <stop offset=".52" stop-color="#433C83"/>
          <stop offset="1" stop-color="#18283D"/>
        </linearGradient>
        <linearGradient id="cover1" x1="1" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="#254653"/>
          <stop offset=".48" stop-color="#493B76"/>
          <stop offset="1" stop-color="#1A2037"/>
        </linearGradient>
      </defs>
      <rect width="1080" height="2280" fill="url(#background)"/>
      <text x="66" y="72" fill="#F4F6FF" font-size="27" font-family="DejaVu Sans">9:41</text>
      <g fill="none" stroke="#F4F6FF" stroke-width="5" stroke-linecap="round">
        <path d="M865 55v13m14-20v20m14-27v27"/>
        <path d="M920 53h34l-17 18z"/>
      </g>
      <rect x="973" y="43" width="37" height="27" rx="6" fill="none" stroke="#F4F6FF" stroke-width="4"/>
      <rect x="1012" y="51" width="5" height="11" rx="2" fill="#F4F6FF"/>
      <path d="M95 154l-24 24 24 24" fill="none" stroke="#F4F6FF" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
      <text x="540" y="188" text-anchor="middle" fill="#F4F6FF" font-size="28"
            font-family="DejaVu Sans" font-weight="700" letter-spacing="4">PRO MUSIC PLAYER</text>
      <circle cx="984" cy="178" r="6" fill="#F4F6FF"/>
      <circle cx="984" cy="196" r="6" fill="#F4F6FF"/>
      <circle cx="984" cy="214" r="6" fill="#F4F6FF"/>
      {body}
      <path d="M78 2178h924" stroke="#34394B" stroke-width="2"/>
      <circle cx="245" cy="2223" r="12" fill="{accent}"/>
      <circle cx="540" cy="2223" r="12" fill="#7D849A"/>
      <circle cx="835" cy="2223" r="12" fill="#7D849A"/>
      <rect x="404" y="2252" width="272" height="10" rx="5" fill="#F4F6FF"/>
    </svg>"""


def widget_svg(name: str, width: int, height: int) -> str:
    accent = "#54DDF5"
    if name == "widget_big_info":
        content = """
          <circle cx="544" cy="191" r="142" fill="none" stroke="#54DDF5" stroke-width="12" opacity=".6"/>
          <circle cx="544" cy="191" r="91" fill="none" stroke="#A88BFA" stroke-width="7" opacity=".8"/>
          <text x="36" y="76" fill="#F4F6FF" font-size="40" font-weight="700">Local track</text>
          <text x="36" y="119" fill="#AEB5C8" font-size="25">From your library</text>
          <g fill="#F4F6FF"><path d="M94 260h12v55H94z"/><path d="M107 260l40 27.5-40 27.5z"/>
            <path d="M310 260h12v55h-12zM338 260h12v55h-12z"/>
            <path d="M510 260l40 27.5-40 27.5z"/><path d="M550 260h12v55h-12z"/>
          </g>
        """
    elif name == "widget_card_info":
        content = """
          <rect width="104" height="104" fill="url(#cover)"/>
          <circle cx="52" cy="52" r="32" fill="none" stroke="#54DDF5" stroke-width="5"/>
          <text x="124" y="43" fill="#F4F6FF" font-size="22" font-weight="700">Local track</text>
          <text x="124" y="73" fill="#AEB5C8" font-size="17">From your library</text>
          <g fill="#AEB5C8"><path d="M376 37h8v30h-8z"/><path d="M385 37l23 15-23 15z"/>
            <path d="M445 37h8v30h-8zM463 37h8v30h-8z"/>
            <path d="M521 37l23 15-23 15z"/><path d="M544 37h8v30h-8z"/>
          </g>
        """
    elif name == "widget_classic":
        content = """
          <rect width="164" height="164" fill="url(#cover)"/>
          <circle cx="82" cy="82" r="54" fill="none" stroke="#54DDF5" stroke-width="7"/>
          <text x="184" y="47" fill="#F4F6FF" font-size="23" font-weight="700">Local track</text>
          <text x="184" y="78" fill="#AEB5C8" font-size="17">From your library</text>
          <g fill="#AEB5C8"><path d="M212 113h8v29h-8z"/><path d="M221 113l21 15-21 14z"/>
            <path d="M304 113h8v29h-8zM322 113h8v29h-8z"/>
            <path d="M402 113l21 15-21 14z"/><path d="M423 113h8v29h-8z"/>
          </g>
        """
    elif name == "widget_small":
        content = """
          <rect x="8" y="8" width="108" height="140" rx="20" fill="url(#cover)"/>
          <circle cx="62" cy="77" r="35" fill="none" stroke="#54DDF5" stroke-width="5"/>
          <text x="132" y="56" fill="#F4F6FF" font-size="21" font-weight="700">Local track</text>
          <text x="132" y="84" fill="#AEB5C8" font-size="16">On this device</text>
          <g fill="#AEB5C8"><path d="M150 111h7v26h-7z"/><path d="M158 111l19 13-19 13z"/>
            <path d="M220 111h7v26h-7zM237 111h7v26h-7z"/>
            <path d="M294 111l19 13-19 13z"/><path d="M313 111h7v26h-7z"/>
          </g>
        """
    else:
        content = """
          <circle cx="255" cy="30" r="70" fill="none" stroke="#54DDF5" stroke-width="7" opacity=".55"/>
          <text x="255" y="93" text-anchor="middle" fill="#F4F6FF" font-size="31" font-weight="700">Local track</text>
          <text x="255" y="130" text-anchor="middle" fill="#AEB5C8" font-size="22">From your library</text>
          <g fill="#F4F6FF"><path d="M110 160h10v36h-10z"/><path d="M121 160l28 18-28 18z"/>
            <path d="M242 160h10v36h-10zM262 160h10v36h-10z"/>
            <path d="M361 160l28 18-28 18z"/><path d="M389 160h10v36h-10z"/>
          </g>
        """

    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
      <defs>
        <linearGradient id="surface" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stop-color="#242A3C"/><stop offset="1" stop-color="#151925"/>
        </linearGradient>
        <linearGradient id="cover" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stop-color="#384C75"/><stop offset=".5" stop-color="#55498D"/>
          <stop offset="1" stop-color="#1C3341"/>
        </linearGradient>
      </defs>
      <rect width="{width}" height="{height}" rx="18" fill="url(#surface)"/>
      {content}
    </svg>"""


def lyrics_svg(theme: str, mode: str) -> str:
    if theme == "light":
        background, surface, text, muted, accent = "#EEF1F7", "#FFFFFF", "#202536", "#667085", "#287F91"
    elif theme == "black":
        background, surface, text, muted, accent = "#000000", "#090A0D", "#F4F6FF", "#AEB5C8", "#54DDF5"
    else:
        background, surface, text, muted, accent = "#10131D", "#191D2B", "#F4F6FF", "#AEB5C8", "#54DDF5"

    backdrop = (
        f'<rect x="0" y="220" width="1080" height="2060" fill="url(#cover)" opacity=".32"/>'
        if mode == "over"
        else ""
    )
    lines = (
        "Dancing through the midnight",
        "Every note returns to me",
        "Music carries us forward",
        "We can stay a little longer",
        "Let the quiet turn to light",
        "One more song, one more moment",
    )
    lyric_markup = ""
    for index, line in enumerate(lines):
        y = 835 + index * 172
        color = accent if index == 2 else text
        opacity = "1" if index == 2 else ".78"
        lyric_markup += (
            f'<text x="540" y="{y}" text-anchor="middle" fill="{color}" '
            f'opacity="{opacity}" font-size="43" font-weight="{"700" if index == 2 else "400"}">'
            f'{line}</text>'
        )

    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="2280" viewBox="0 0 1080 2280">
      <defs>
        <linearGradient id="cover" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stop-color="#25435B"/><stop offset=".52" stop-color="#514276"/>
          <stop offset="1" stop-color="#172636"/>
        </linearGradient>
      </defs>
      <rect width="1080" height="2280" fill="{background}"/>
      {backdrop}
      <rect x="62" y="200" width="956" height="1870" rx="42" fill="{surface}" opacity=".9"/>
      <text x="540" y="294" text-anchor="middle" fill="{text}" font-size="28" font-weight="700" letter-spacing="4">SYNCHRONIZED LYRICS</text>
      <text x="540" y="376" text-anchor="middle" fill="{text}" font-size="39" font-weight="700">Local track</text>
      <text x="540" y="428" text-anchor="middle" fill="{muted}" font-size="25">From your library</text>
      <path d="M140 506h800" stroke="{accent}" stroke-width="4" opacity=".65"/>
      {lyric_markup}
      <rect x="395" y="1925" width="290" height="6" rx="3" fill="{muted}" opacity=".45"/>
      <rect x="395" y="1925" width="135" height="6" rx="3" fill="{accent}"/>
      <circle cx="540" cy="2190" r="52" fill="{accent}"/>
      <path d="M527 2161v58l46-29z" fill="{background}"/>
    </svg>"""


def material_art_svg() -> str:
    return """<svg xmlns="http://www.w3.org/2000/svg" width="1026" height="440" viewBox="0 0 1026 440">
      <defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="#10131D"/><stop offset="1" stop-color="#25203F"/>
      </linearGradient></defs>
      <rect width="1026" height="440" fill="url(#bg)"/>
      <circle cx="770" cy="222" r="190" fill="#7157F5" opacity=".2"/>
      <circle cx="770" cy="222" r="142" fill="none" stroke="#54DDF5" stroke-width="5" opacity=".85"/>
      <circle cx="770" cy="222" r="96" fill="none" stroke="#A88BFA" stroke-width="8" opacity=".7"/>
      <path d="M0 340c160-130 270 30 415-80s248-30 360 17 180-22 251-98v261H0z" fill="#54DDF5" opacity=".16"/>
      <path d="M0 383c157-91 279 5 405-63s231-32 341 18 183 9 280-51v153H0z" fill="#A88BFA" opacity=".24"/>
      <g fill="#F4F6FF" opacity=".9"><rect x="688" y="177" width="12" height="90" rx="6"/>
        <rect x="724" y="148" width="12" height="148" rx="6"/><rect x="760" y="194" width="12" height="58" rx="6"/>
        <rect x="796" y="135" width="12" height="178" rx="6"/><rect x="832" y="174" width="12" height="98" rx="6"/>
      </g>
    </svg>"""


def main() -> None:
    branding = ROOT / "branding"
    main_res = ANDROID / "res"
    icon_svg = branding / "promusic-icon.svg"
    with tempfile.TemporaryDirectory(prefix="promusic-art-") as temp_dir:
        temp = Path(temp_dir)

        convert(icon_svg, ANDROID / "ic_launcher-playstore.png", "512x512")
        convert(icon_svg, ANDROID / "ic_launcher-web.png", "512x512")
        convert(
            icon_svg,
            ROOT / "fastlane/metadata/android/en-US/images/icon.png",
            "512x512",
        )
        convert(
            branding / "feature-graphic.svg",
            ROOT / "fastlane/metadata/android/en-US/images/featureGraphic.png",
            "1024x500",
        )

        for density, pixels in (
            ("mdpi", 48),
            ("hdpi", 72),
            ("xhdpi", 96),
            ("xxhdpi", 144),
            ("xxxhdpi", 192),
        ):
            for suffix in ("", "_round"):
                convert(
                    icon_svg,
                    main_res / f"mipmap-{density}/ic_launcher{suffix}.png",
                    f"{pixels}x{pixels}",
                )

        for index, name in enumerate(PREVIEW_NAMES):
            svg_path = temp / f"{name}.svg"
            svg_path.write_text(
                preview_svg(name, ACCENTS[index % len(ACCENTS)], index),
                encoding="utf-8",
            )
            convert(
                svg_path,
                main_res / f"drawable-xxxhdpi/{name}.webp",
                "1080x2280",
                quality="82",
            )

        for name, (width, height) in WIDGET_SIZES.items():
            svg_path = temp / f"{name}.svg"
            svg_path.write_text(widget_svg(name, width, height), encoding="utf-8")
            convert(svg_path, main_res / f"drawable/{name}.webp", f"{width}x{height}", quality="82")

        material_svg = temp / "material_design_default.svg"
        material_svg.write_text(material_art_svg(), encoding="utf-8")
        convert(
            material_svg,
            main_res / "drawable/material_design_default.webp",
            "1026x440",
            quality="82",
        )

        screenshots = ROOT / "screenshots"
        for name, preview in README_PREVIEWS.items():
            convert(
                main_res / f"drawable-xxxhdpi/{preview}.webp",
                screenshots / f"{name}.jpg",
                "800x1689",
                quality="84",
            )

        for mode in ("over", "replace"):
            for theme in ("light", "dark", "black"):
                svg_path = temp / f"synced_{mode}_{theme}.svg"
                svg_path.write_text(lyrics_svg(theme, mode), encoding="utf-8")
                convert(
                    svg_path,
                    screenshots / f"synced_{mode}_{theme}.jpg",
                    "800x1689",
                    quality="84",
                )

    print("Generated ProMusic launcher, Play Store, and player-preview images.")


if __name__ == "__main__":
    main()